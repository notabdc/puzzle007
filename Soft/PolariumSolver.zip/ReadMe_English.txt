	PolariumSolver

	NOTE: this program needs MFC7.1 to run. You will get "Missing ***.dll" prompt if MFC7.1 is not installed. 
	You can get MFC7.1 on my homepage:
	http://notabdc.vip.sina.com/Soft/Mfc71.zip
	http://www.freewebs.com/gamesolver/Soft/Mfc71.zip
	Download it and then extract the files in the zip package to the same folder of PolariumSolver.

	Author:	Ge Yong
	Email:	notabdc@gmail.com
	Homepage: www.puzzle007.net

	This tool helps you solve DS game "Polarium". 
	Left click to flip color. 
	Right click to set start point. Start point is optional, this makes the solver runs quicker.
	If you just want to enjoy solving the puzzle yourself, this feature will be helpful: double click on the edge will flip a whole line. This doesn't change level's difficulty, but reduce the requirement to remember every line's "target color".