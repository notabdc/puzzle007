	Puzzle007 Copy readme

	When copying file through my PC's USB1.1 interface, I need to limit the transfer speed. I find Nullsoft Copy V0.1 (http://www.nullsoft.com/free/nscopy/) is the one I need. But it can only add folders as copy source, not files. So I decide to improve it.

	After reading the source, I am so surprised to find that it lacks many very important features such as disk full handling, overwrite prompting, etc. In other words, files may be incorrectly copied without prompting.

	I rewrite the whole code about copying, and, by the way, improve the interface a little. Here are some new features I add:

	Add files as copy source.
	Unicode file names supported.
	Overwrite prompting.
	Disk full prompting.
	Progress bar based on file size.

	Note though I write the code carefully, it's not widely tested. In no event will the authors be held liable for any damages arising from the use of this software.
 
	Puzzle007 Copy is open source. You can ask for the source via Email.		

	My name: Ge yong
	My homepage: www.puzzle007.net	notabdc.vip.sina.com
	My Email: notabdc@vip.sina.com

