		BoxSearch 4.1.3 -- Tool for solving Sokoban
		
	NOTE: this program need MFC7.1 to run. You will get "Missing ***.dll" prompt if MFC7.1 is not installed. 
	You can get MFC7.1 on my homepage:
	http://notabdc.vip.sina.com/Soft/Mfc71.zip
	http://www.freewebs.com/gamesolver/Soft/Mfc71.zip
	Download it and then extract the files in the zip package to the same folder of boxsearch4.

== What's new
	4.1.3
	Large levels (60*60) supported. Add "zoom in/out" feature to level displaying.

	4.1.2
	Answer optimization can begin at any step of the whole answer.
	
	4.1
	Better support for answer in LrUd format.
	Add new feature: answer optimization. Note: there is no assurance that the optimized answer is the best one. The original answer takes the responsibility that the answer is well organized globally.
		
== About Algorithm
	The main algorithm is used to solve sokoban game QUICKLY, the answer is not best-push or best-move. There are other algorithms in my tool to get best-push or best-move, but they are much slower. 
	
== Usage of the tool
	Here are some usages not obviously.	
	"Edit"-"Destination of people", this can help you solve part of a large map.
	The program try to split the whole map into two parts--"box area" & "goal area", if a "cut point" can be found. You can skip one phase in the option dialog.
	In "try play" mode, the method to push a box is: click the position behind the box, then move cursor to the destination of the push, hold down right mouse, then left click.

== Contact Author
	Author: Ge yong
	Email: 
		notabdc@vip.sina.com
		notabdc@hotmail.com
	Homepage:
		http://notabdc.vip.sina.com
		http://www.freewebs.com/gamesolver
		
== My other software
	You can get following software on my homepage.
	FreecellTool: Solve any freecell game. You don't need to edit game manually. The program catches it from windows for you!
	AutoSweeper: Do minesweeper automatically!
	MineTris: Play minesweeper with endless increasing grids, get much fun than classic minesweeper!
	
	And more, if you can read Chinese, you can get my game solver programs written in Chinese on my Chinese homepage (There are also links on English homepage). They are:
	AutoTetris: play tetris automatically
	AutoJYTK(author: Jin you): tetris with two players attack each other
	AutoRubiksCube(author: Jin you): solve rubiks cube
	Diamond(author: Mao ji & me): solve Peg Solitaire
	HuaRongDaoTool: solve classic Chinese puzzle "HuaRongDao", also known as Klotski
	SiChuanSheng: solve puzzle "SiChuanSheng", very like "Shanghai", in which you can remove a pair when they can connect by no more than 3 lines
	TwelveTool(author: Mao ji): solve classic puzzle "the 12 blocks"
	Wmf(author: Hu bo): Rubics cube on dodecahedron
		
== recommend my favorite Sokoban game
	This is the best game of Sokoban game I have seen! Its name: SuperSoko, you can get it from www.supersoko.com